/*
  Renders monthly Oil/Gas production as points and Oil/Gas forecasts as solid lines,
  plus a dashed gray well-count line on a secondary axis. Data source: window.productionByApi
  (populated by existing /bulk-production call from WELLS.MINERALS.FORECASTS).
  Why-comments only where non-obvious.
*/
(function(){
  const OIL_COLOR = '#1e8f4e';
  const GAS_COLOR = '#d62728';
  const COUNT_COLOR = '#888888';

  function toMonthKey(d){
    const dt = new Date(d);
    if (isNaN(dt)) return null;
    const y = dt.getUTCFullYear();
    const m = String(dt.getUTCMonth() + 1).padStart(2, '0');
    return `${y}-${m}-01`;
  }

  function monthLabel(key){
    // keep labels compact without requiring a time adapter
    return key ? key.slice(0,7) : '';
  }

  function num(v){
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  }

  function buildMonthlyAggregate(raw){
    // Supports two shapes: { api -> rows[] } or flat rows[] with API_UWI field.
    const rows = Array.isArray(raw)
      ? raw
      : Object.values(raw || {}).flat();

    const monthly = new Map(); // key -> { oilProd, gasProd, oilFcst, gasFcst, apis:Set }

    for(const r of rows){
      const api = r.API_UWI || r.api_uwi || r.Api_Uwi;
      const mk = toMonthKey(r.PRODUCINGMONTH || r.ProducingMonth || r.producingmonth || r.MONTH || r.month);
      if(!mk || !api) continue;
      let agg = monthly.get(mk);
      if(!agg){ agg = { oilProd:0, gasProd:0, oilFcst:0, gasFcst:0, apis:new Set() }; monthly.set(mk, agg); }
      agg.oilProd  += num(r.LIQUIDSPROD_BBL || r.OIL_BBL || r.oil_bbl);
      agg.gasProd  += num(r.GASPROD_MCF    || r.GAS_MCF || r.gas_mcf);
      agg.oilFcst  += num(r.OilFcst_BBL    || r.OILFCST_BBL || r.oilfcst_bbl);
      agg.gasFcst  += num(r.GasFcst_MCF    || r.GASFCST_MCF || r.gasfcst_mcf);
      agg.apis.add(String(api));
    }

    // Trim forecast backlog per your rule (remove old forecast except last 6 prod months)
    const sortedKeys = Array.from(monthly.keys()).sort();
    let latestProdKey = null;
    for(const k of sortedKeys){
      const a = monthly.get(k);
      if((a.oilProd > 0) || (a.gasProd > 0)) latestProdKey = k;
    }
    if(latestProdKey){
      // Build set of last 6 months including latest production month
      const last6 = new Set();
      const dt = new Date(latestProdKey + 'T00:00:00Z');
      for(let i=0;i<6;i++){
        const d = new Date(Date.UTC(dt.getUTCFullYear(), dt.getUTCMonth() - i, 1));
        last6.add(`${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,'0')}-01`);
      }
      for(const k of sortedKeys){
        if(k < latestProdKey && !last6.has(k)){
          const a = monthly.get(k);
          a.oilFcst = null;
          a.gasFcst = null;
        }
      }
    }

    // Build arrays for chart
    const labels = sortedKeys;
    const oilProd = labels.map(k => monthly.get(k).oilProd || null);
    const gasProd = labels.map(k => monthly.get(k).gasProd || null);
    const oilFcst = labels.map(k => {
      const v = monthly.get(k).oilFcst; return (v === 0 ? 0 : v) ?? null;
    });
    const gasFcst = labels.map(k => {
      const v = monthly.get(k).gasFcst; return (v === 0 ? 0 : v) ?? null;
    });
    const wellCount = labels.map(k => monthly.get(k).apis.size);

    // Compute log scale domain for volumes
    const vols = [];
    for(let i=0;i<labels.length;i++){
      const v1 = oilProd[i]; if(v1>0) vols.push(v1);
      const v2 = gasProd[i]; if(v2>0) vols.push(v2);
      const v3 = oilFcst[i]; if(v3>0) vols.push(v3);
      const v4 = gasFcst[i]; if(v4>0) vols.push(v4);
    }
    let yMin = 1, yMax = 1000;
    if(vols.length){
      const min = Math.min(...vols);
      const max = Math.max(...vols);
      yMin = Math.pow(10, Math.floor(Math.log10(min)));
      yMax = Math.pow(10, Math.ceil(Math.log10(max)));
    }
    const wcMax = Math.max(1, Math.max(...wellCount, 0)) + 3;

    return { labels, oilProd, gasProd, oilFcst, gasFcst, wellCount, yMin, yMax, wcMax };
  }

  function renderChart(data){
    const ctx = document.getElementById('prodChart');
    if(!ctx) return;
    // Recreate cleanly if rerun
    if(window._prodChart){ window._prodChart.destroy(); }

    const labels = data.labels.map(monthLabel);

    window._prodChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [
          { label: 'Oil (BBL)', data: data.oilProd, borderColor: OIL_COLOR, backgroundColor: OIL_COLOR,
            yAxisID: 'y', fill: false, showLine: false, pointRadius: 3, pointHoverRadius: 4, pointHitRadius: 6, borderWidth: 0, order: 1 },
          { label: 'Gas (MCF)', data: data.gasProd, borderColor: GAS_COLOR, backgroundColor: GAS_COLOR,
            yAxisID: 'y', fill: false, showLine: false, pointRadius: 3, pointHoverRadius: 4, pointHitRadius: 6, borderWidth: 0, order: 1 },
          { label: 'Oil Forecast (BBL)', data: data.oilFcst, borderColor: OIL_COLOR, backgroundColor: 'transparent',
            yAxisID: 'y', fill: false, tension: 0.25, pointRadius: 0, borderWidth: 2, order: 0 },
          { label: 'Gas Forecast (MCF)', data: data.gasFcst, borderColor: GAS_COLOR, backgroundColor: 'transparent',
            yAxisID: 'y', fill: false, tension: 0.25, pointRadius: 0, borderWidth: 2, order: 0 },
          { label: 'Well Count', data: data.wellCount, borderColor: COUNT_COLOR, backgroundColor: 'transparent',
            yAxisID: 'y2', fill: false, pointRadius: 0, borderWidth: 1.5, borderDash: [4,3], order: 2 },
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { position: 'top' },
          tooltip: {
            callbacks: {
              // clarify units in tooltip
              label: (ctx) => {
                const l = ctx.dataset.label || '';
                const v = ctx.parsed.y;
                if(l.includes('Well Count')) return `${l}: ${v}`;
                return `${l}: ${v?.toLocaleString()}`;
              }
            }
          }
        },
        scales: {
          y: {
            type: 'logarithmic',
            min: data.yMin,
            max: data.yMax,
            title: { display: true, text: 'MCF or BBL per Month' },
            ticks: {
              callback: (v) => {
                // prettier tick labels on log scale
                const p = Math.log10(v);
                return Number.isInteger(p) ? v : '';
              }
            }
          },
          y2: {
            type: 'linear', position: 'right', grid: { drawOnChartArea: false },
            suggestedMin: 0, suggestedMax: data.wcMax,
            title: { display: true, text: 'Well Count' }
          },
          x: { title: { display: true, text: 'Production Month' } }
        }
      }
    });
  }

  function init(){
    // Wait for the global cache filled by /bulk-production.
    const tryBuild = () => {
      const raw = window.productionByApi;
      if(!raw || (Array.isArray(raw) && !raw.length) || (typeof raw === 'object' && !Array.isArray(raw) && !Object.keys(raw).length)){
        return false;
      }
      const agg = buildMonthlyAggregate(raw);
      renderChart(agg);
      return true;
    };

    if(!tryBuild()){
      let tries = 0;
      const h = setInterval(() => {
        tries++;
        if(tryBuild() || tries > 60){ clearInterval(h); }
      }, 500);
    }

    // Expose a manual refresh hook if upstream data changes later on the page
    window.refreshProductionChart = function(){
      const agg = buildMonthlyAggregate(window.productionByApi || {});
      renderChart(agg);
    };
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();